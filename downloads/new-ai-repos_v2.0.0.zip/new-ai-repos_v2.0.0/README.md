<!-- 版本：v2.0.0 | 更新时间：2026-09-08 | 状态：本月新仓库独立配套资料 -->

# 只看9月新建：6个AI开源项目

作者：才哥AGI。对应《只看9月新建：这6个AI开源项目，可以拿来做什么》。本篇重新筛选六个2026年9月新建仓库，和此前8个项目清单完全不同。

## 使用方法

1. 打开 `本月项目选型表_v2.0.0.csv`，按场景挑选。
2. 在 `任务单/` 中选择对应文件：六个项目各有不同任务、验证范围和结果填写区。
3. `六个项目快照_v2.0.0.json` 含创建时间、Star、许可证、默认分支SHA、README SHA和代码历史边界；`来源索引_v2.0.0.json` 可回到官方。

创建范围为2026年9月（UTC），本篇采样截至9月8日。创建新仓库不等于此时才开发第一行代码，也不能证明此前从未有人介绍。Commerce Agents 中有8月代码提交，且官方明确其为不维护、不接受贡献的参考实现。

## 重现本月筛选检查

只需 Python 3.10+，不需要额外 Python 依赖：

```bash
python 核验本月范围_v2.0.0.py
python 核验本月范围_v2.0.0.py --refresh --use-gh
```

第一行离线复核六个项目，并检查月初、月末、Fork和归档边界。第二行要求本机已安装并登录 GitHub CLI，通过它读取公开仓库信息，不读取或输出令牌。

没有 GitHub CLI 时，可以用 `--refresh` 匿名请求公开 API；GitHub 匿名限流会记为逐项失败。本次匿名请求遇到HTTP限流，随后GitHub CLI路径成功核验6/6。结果写入带时间戳的 `本地运行输出/`，不覆盖快照。Star随时间变化，新值无需与文章静态数字完全相同。

GitHub 搜索发现式：`created:2026-09-01..2026-09-08 stars:>20 fork:false archived:false`。这是跨领域候选搜索，之后人工筛选AI用途；不代表完整AI仓库总量或性能排行。

## 本次验证范围

- M3E Canvas：实际打开官方在线版，打开提示词面板，确认默认画布输出含布局与主题说明。没有填写模型Key，也没有让编程工具继续生成应用。
- 其余五个项目：核验官方README、API元数据、许可证和入口；没有安装执行、读取现有登录凭据或调用付费模型。
- 8张图中，`02_M3E真实界面_v2.0.0.png` 为实际在线版截图，其余是本篇原创图解或基于API快照的图表；不把图解当作软件运行结果。

截图来源：[M3E Canvas](https://lnkiai.github.io/m3e-canvas/)，项目作者 lnkiai，MIT；许可证保留在 `M3E许可证_v2.0.0.md`。图中默认示例不代表完成了读者自己的应用。

## 独立下载

- [本篇目录](https://github.com/dxawdc/caige-wechat-articles/tree/main/articles/2026-09-08-new-ai-repos)
- [本篇ZIP](https://raw.githubusercontent.com/dxawdc/caige-wechat-articles/main/downloads/new-ai-repos_v2.0.0.zip)

v2.0.0：按“本月新建”要求重新构建选题、正文与全部任务资料。此前材料保留，但不属于本篇ZIP。

[返回资料库](https://github.com/dxawdc/caige-wechat-articles) · [维护与更新规则](https://github.com/dxawdc/caige-wechat-articles/blob/main/CONTRIBUTING.md)
