<!-- 版本：v1.0.0 | 更新时间：2026-09-08 | 状态：本篇独立配套资料 -->

# 8 个 AI 开源项目：选型与试用资料

作者：才哥AGI。对应《GitHub上这8个AI开源项目，值得拿来干点正事》。这里只提供配套资料，不包含未发表的文章全文。

## 从哪里开始

1. 用 Excel 打开 `项目选型表_v1.0.0.csv`，按场景与门槛挑选项目。
2. 打开 `任务卡/` 中对应项目的文件。8 张卡片各有不同输入、目标、验收项和结果填写区域。
3. 查 `来源索引_v1.0.0.json` 与 `项目数据_v1.0.0.json` 回到官方资料；Star 是 2026-09-08 快照，创建时间不等于首次发布。

## 运行实际转换案例

安装 Python 3.10+，建议单独建立虚拟环境。进入解压后的本篇目录执行：

```bash
python -m pip install -r requirements_v1.0.0.txt
python -X utf8 运行转换案例_v1.0.0.py
```

`活动样本_v1.0.0.xlsx` 为教学模拟数据，有“活动数据”和“统计口径”两张表。脚本实际调用 MarkItDown 本地转换，检查表头与渠道 A、B 的关键数值，并输出到 `本地运行输出/`。它不调用模型、不访问业务后台。合计付费率 152/1800 由案例脚本另行计算，不代表 MarkItDown 自动完成了指标分析。

`验证记录/` 保存本次实际转换输出与检查报告。读取其他文件、扫描 PDF、复杂合并单元格等不属于本次验证范围。不要把本例成功推断为所有格式均能准确转换。

## 刷新公开仓库信息

```bash
python -X utf8 刷新GitHub数据_v1.0.0.py
```

只需 Python 标准库，不要求提供账号或令牌。脚本读取 8 个公开仓库的 GitHub 官方 API，将结果存为带时间戳的新文件，不覆盖文章快照。网络失败和 API 限流会逐仓库记录；本次现场测试成功 8/8。`pushed_at` 是仓库推送时间，不能当成默认分支发布新版本的日期；原始快照另含 `head_date` 和 `head_sha`。

## 图片和使用边界

`图片/` 含 10 张原创 PNG 与对应 HTML。关注度图使用本篇实际 API 快照，文件转换图依据真实输出整理，其余为建议试用流程图，不是运行截图。HTML 可用浏览器直接打开；离线素材没有外部脚本、追踪或字体下载。

除 MarkItDown 的本地样本转换外，其余七个项目本篇仅做官方资料核验，没有完整部署或性能测试。使用任何项目都应查看其当前 README、依赖和许可证；模型与其他外部服务费用另算。

## 本篇下载

- [资料目录](https://github.com/dxawdc/caige-wechat-articles/tree/main/articles/2026-09-08-ai-open-source)
- [独立 ZIP](https://raw.githubusercontent.com/dxawdc/caige-wechat-articles/main/downloads/ai-open-source_v1.0.0.zip)

不要使用仓库的 Code → Download ZIP 代替本篇下载，那会取得全部文章的材料。

## 版本说明

v1.0.0：首次整理 8 个项目，提供独立任务卡、来源快照、10 张图解、可复现转换案例和数据刷新脚本。

[返回资料库](https://github.com/dxawdc/caige-wechat-articles) · [维护与更新规则](https://github.com/dxawdc/caige-wechat-articles/blob/main/CONTRIBUTING.md)
