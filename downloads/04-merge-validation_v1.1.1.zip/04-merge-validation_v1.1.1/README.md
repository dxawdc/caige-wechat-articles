# pandas合并后金额翻倍，问题出在哪里：专属资料包

<!-- 版本：v1.1.1 | 更新时间：2026-09-06 | 状态：独立包、独立验证 -->

文章标识：**04-merge-validation**。作者：才哥AGI。全部业务数据为教学模拟。

## 本包解决什么问题

订单与重复用户维表 → 扩行诊断 → 多对一校验 → 时间生效渠道匹配。

预期结果：**错误关联 3→6 行、600→1200 元；修复后回到 3 行、600 元。历史渠道 P1=A、P2=B，不能将过去订单全部归为最新渠道。**

## 独立下载与运行

[仅下载本篇 ZIP](https://raw.githubusercontent.com/dxawdc/caige-wechat-articles/main/downloads/04-merge-validation_v1.1.1.zip)。解压后进入 `04-merge-validation_v1.1.1` 目录，使用 Python 3.12：

```powershell
python -m pip install -r requirements_v1.1.1.txt
python "运行_04_Pandas关联审计_v1.1.1.py"
```

专属入口先复制本包材料到 `运行结果/04-merge-validation/`，再运行本篇基础和进阶脚本。包内原始样例与清单保持不变；重复运行会更新该输出目录的教学结果。请勿将真实业务文件放入这个输出目录。

基础脚本：`案例与绘图_v1.0.0.py`。进阶脚本：`进阶案例_v1.1.0.py`。绘图工具及部分依赖跨篇复用，核心案例、输入数据、结果和本包入口属于本篇。

## 本篇文件与结果

| 文件 | 内容 |
|---|---|
| `数据/订单_v1.0.0.csv` | 3 笔订单、600 元 |
| `数据/重复用户维表_v1.0.0.csv` | U1/U2 各重复 2 行 |
| `数据/错误合并_v1.0.0.csv` | 6 行、1200 元 |
| `数据/正确合并_v1.0.0.csv` | 3 行、600 元 |
| `数据/历史渠道匹配_v1.1.0.csv` | 独立进阶情景 P1/P2 按生效日匹配 A/B |

`图片/` 含本篇封面及 3 张实际结果图；`结果/` 是计算验收记录。基础与进阶情景各自的口径已在脚本及结果中说明，不将不同情景的数据混合。

## 核对资料是否正确

本包唯一标识为 `04-merge-validation`，专属入口名称包含“Pandas关联审计”。当前材料以 `物料清单_v1.1.1.json` 的 articleId、entrypoint、files 为准，可逐项校验 SHA-256。ZIP 只包含当前运行所需材料，不混入其他文章。

当前目录与独立包仅保留最新完整物料；历史修订通过 Git 提交查看。基础脚本和未变化的数据保留原文件名，不能只按版本号删除依赖。

中文绘图优先使用 Microsoft YaHei，其他系统可安装 Noto Sans CJK SC；字体不同可能影响图片像素，不影响表格数值。

## 版本说明

v1.1.1：提供本篇独立下载、专属说明与入口、当前校验清单；执行输出与原始物料分开。保留已验证的基础与进阶案例。

[返回资料库](https://github.com/dxawdc/caige-wechat-articles) · [维护与更新规则](https://github.com/dxawdc/caige-wechat-articles/blob/main/CONTRIBUTING.md)
